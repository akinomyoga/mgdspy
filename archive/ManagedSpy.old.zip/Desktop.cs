using Interop=System.Runtime.InteropServices;
using User32=mwg.Win32.User32;
using Kernel32=mwg.Win32.Kernel32;
namespace ManagedSpy{
	public class EventRegister{
		public System.Windows.Forms.Control sourceWindow;
		public int eventCode;
		public System.Reflection.EventInfo eventInfo;
		public System.IntPtr targetEventReceiver;
		public void OnEventFired(object sender,System.EventArgs args){
			System.Collections.ArrayList @params=new System.Collections.ArrayList();
			@params.Add(sourceWindow.Handle);
			@params.Add(eventCode);
			if(args==System.EventArgs.Empty||args.GetType().IsSerializable){
				@params.Add(args);
			}else if(typeof(System.Windows.Forms.MouseEventArgs).IsAssignableFrom(args.GetType())){
				@params.Add(new SerializableMouseEventArgs((System.Windows.Forms.MouseEventArgs)args));
			}else{
				@params.Add(new NonSerializableEventArgs(args));
			}
			Desktop.SendMarshaledMessage(targetEventReceiver,WM_EVENTFIRED,@params,false);
		}
	}
	public class Desktop{
		private static System.IntPtr _messageHookHandle=System.IntPtr.Zero;
		private static readonly System.IntPtr NULL=System.IntPtr.Zero;
		private Desktop(){}
		//
		//		�ÓI�t�B�[���h
		//
		// generics <ControlProxy>
		public static System.Collections.ArrayList topLevelWindows=new System.Collections.ArrayList();
		// generics <ControlProxy>
		public static System.Collections.ArrayList childWindows=new System.Collections.ArrayList();
		// generics <int>
		public static System.Collections.ArrayList managedProcesses=new System.Collections.ArrayList();
		// generics <int>
		public static System.Collections.ArrayList unmanagedProcesses=new System.Collections.ArrayList();
		public static eventTargetWindow eventWindow=new EventTargetWindow();
		//generics <System.IntPtr,System.Collections.IDictionary<int,EventRegister>>
		public static System.Collections.IDictionary eventCallbacks=new System.Collections.Hashtable();
		//generics <System.IntPtr,ControlProxy>
		public static System.Collections.IDictionary proxyCache=new System.Collections.Hashtable();
		//generics <System.Type,System.Reflection.DynamicMethod>
		public static System.Collections.IDictionary eventMethodCache=new System.Collections.Hashtable();
		public static int eventTypeCount=0;
		public static System.Reflection.MethodInfo eventCalback=null;
		//
		//		�ÓI���\�b�h
		//
		public static void EnableHook(System.IntPtr windowHandle){
			System.IntPtr hDll=Kernel32.LoadLibrary("ManagedSpy.dll");

			DisableHook();
			uint Null;
			int tid=User32.GetWindowThreadProcessId(hWnd,out Null);

			User32.HookProc callback=new User32.HookProc(this.MessageHookProc);
			_messageHookHandle=User32.SetWindowsHookEx(User32.WH.CALLWNDPROC,callback,System.IntPtr.Zero,tid);
		}
		public static void DisableHook(){
			if (_messageHookHandle!=NULL) {
				User32.UnhookWindowsHookEx(_messageHookHandle);
				_messageHookHandle=NULL;
			}
		}
		public static void SubscribeEvent(System.Windows.Forms.Control w,System.IntPtr eventWindow,string eventName,int eventCode);
		public static void UnsubscribeEvent(System.Windows.Forms.Control w,int eventCode);
		public static object GetEventHandler(System.Type eventHandlerType,object instance);
		public static bool IsManagedProcess(int procid);
		public static object SendMarshaledMessage(System.IntPtr hWnd,uint Msg,object parameter);
		public static object SendMarshaledMessage(System.IntPtr hWnd,uint Msg,object parameter,bool hookRequired){
			if(hWnd==System.IntPtr.Zero)return null;
			MemoryStore store = MemoryStore.CreateStore(hWnd);
			if(store==null)return null;
			object retval=null;
			if(hookRequired)Desktop.EnableHook(hWnd);

			try{
				retval=store.SendDataMessage(Msg,parameter);
			}finally{
				if(hookRequired)Desktop.EnableHook(hWnd);	//enable it during deletion for memory release messages.
				store=null;
				if(hookRequired)Desktop.DisableHook();
			}
			return retval;		
		}
		public static void OnMessage(int nCode,System.IntPtr wparam,System.IntPtr lparam);
		public static ControlProxy GetProxy(System.IntPtr windowHandle);
		public static ControlProxy[] GetTopLevelWindows();
		private static int MessageHookProc(int nCode,System.IntPtr wparam,System.IntPtr lparam){
			try {
				if (nCode==HC_ACTION) {
					ManagedSpy.Desktop.OnMessage(nCode,wparam,lparam);
				}
			}catch{}
			return User32.CallNextHookEx(this.current,nCode,wparam,lparam);
		}
	}
}
