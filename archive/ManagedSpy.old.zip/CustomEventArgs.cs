namespace ManagedSpy{
	[System.Serializable]
	public class SerializableMouseEventArgs:System.EventArgs{
		public SerializableMouseEventArgs(System.Windows.Forms.MouseEventArgs mArgs){
			Button=mArgs.Button;
			Clicks=mArgs.Clicks;
			X=mArgs.X;
			Y=mArgs.Y;
			Delta=mArgs.Delta;
		}
		public override string ToString(){
			string strversion=string.Format("{ MouseEventArgs [Button:{0} Clicks:{1} X:{2} Y:{3} Delta:{4}] }"
				,Button,Clicks,X,Y,Delta);
			return strVersion;
		}
		public System.Windows.Forms.MouseButtons Button;
		public int Clicks;
		public int X;
		public int Y;
		public int Delta;
	}
	public class NonSerializableEventArgs:System.EventArgs{
		public NonSerializableEventArgs(System.EventArgs nsArgs){
			TypeName=nsArgs.GetType().FullName;
		}
		public override string ToString(){
			string strVersion="{ NonSerializable EventArgs ["+TypeName+"] }";
			return strVersion;
		}
		public string TypeName;
	}
}