using Interop=System.Runtime.InteropServices;
namespace ManagedSpy{
	[Interop.StructLayout(Interop.LayoutKind.Sequential)]
	public struct MGD_CWPSTRUCT{
		public System.IntPtr lParam;
		public System.IntPtr wParam;
		public int message;
		public System.IntPtr hwnd;
	}
	[Interop.StructLayout(Interop.LayoutKind.Sequential)]
	public struct SharedData{
		SIZE_T Size;
		[Interop.MarshalAs(Interop.UnmanagedType.LPArray,SizeConst=1)]
		byte[] Data;
	}
	public class MemoryStore{
		~MemoryStore(){Dispose();}
		public bool StoreParameters(object @params){
			return StoreData(m_Params,@params,m_paramKey);
		}
		public bool StoreReturnValue(object returnvalue){
			return StoreData(m_ReturnValue,returnvalue,m_retvalKey);
		}
		public object GetParameters(){
			return GetData(m_Params,m_paramKey);
		}
		public object GetReturnValue(){
			return GetData(m_ReturnValue,m_retvalKey);
		}
		public int Release(){
			m_nRefCount--;
			if(m_nRefCount==0){
				this.Dispose();
				return 0;
			}
			return m_nRefCount;
		}
		public int AddRef(){
			return ++m_nRefCount;
		}
		public object SendDataMessage(uint Msg,object parameter){
			object retvalObj=null;
			if(parameter!=null){
				StoreParameters(parameter);
			}
			SendMessage(m_notificationWindow,Msg,m_processId,m_transactionId);
			return GetReturnValue();
		}
		public static MemoryStore CreateStore(System.IntPtr notificationWindow);
		public static MemoryStore OpenStore(MGD_CWPSTRUCT message){
			if(message==null)return null;
			return MemoryStore* OpenStore((int)message.wParam,(int)message.lParam,true);
		}
		public static MemoryStore OpenStore(int processId,int transactionId,bool fAddRef){
			MemoryStore store=null;
			if(WaitForSingleObject(s_hMutex,INFINITE) == WAIT_OBJECT_0) {
				try {
					if(s_globalStore[processId].Lookup(transactionId,store)) {
						_ASSERTE(store!=null);
						if(fAddRef)store.AddRef();
					}else if(fAddRef){
						store=new MemoryStore(processId,transactionId,System.IntPtr.Zero);
						s_globalStore[processId][transactionId] = store;
					}
				}finally{
					ReleaseMutex(s_hMutex);
				}
			}
			return store;
		}
		//
		//		�v���C�x�[�g�����o
		//
		private MemoryStore(int processID,int transactionID,System.IntPtr notificationWindow);
		private bool disposed=false;
		private void Dispose(){
			if(this.disposed)return;
			this.disposed=true;
		}
		private bool StoreData(ref CAtlAtlMapping memory,object data,string szMappingName);
		private object GetData(ref CAtlFileMapping data,string szMappingName);

		private CAtlFileMapping m_Params;
		private CAtlFileMapping m_ReturnValue;
		private string m_paramKey;
		private string m_retvalKey;
		private int m_processId;
		private int m_transactionId;
		private int m_nRefCount;
		private System.IntPtr m_notificationWindow;

		private static CAtlMap s_globalStore;
		private static System.IntPtr s_hMutex=CreateMutex(null,false,null);
		private static bool IsHandleValid(System.IntPtr handle){
			return handle!=INVALID_HANDLE_VALUE&&handle!=System.IntPtr.Zero;
		}
	}
}